# Web Page Similarity Audit Report

## Summary

- **Total pages**: 50
- **Successful extractions**: 36
- **Uncertain extractions**: 0
- **Failed extractions**: 0
- **Total pairs analyzed**: 1225
- **Computation time**: 53.52s

## Similarity Findings

- **P1 (High similarity)**: 1 pairs
- **P2 (Moderate similarity)**: 18 pairs
- **P3 (Low similarity)**: 54 pairs

## Template Removal

No common blocks detected (threshold: 60% of 50 pages).

## P1: High Similarity Pairs

| URL 1 | URL 2 | Trigger Reasons |
|-------|-------|-----------------|
| https://eigentime.org | https://eigentime.org/ | SHA-256 exact match; TF-IDF 1.00 >= 0.85; Jaccard 1.00 >= 0.7; Block overlap 1.00 >= 0.8 |
